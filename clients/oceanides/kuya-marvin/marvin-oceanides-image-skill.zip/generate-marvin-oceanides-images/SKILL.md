---
name: generate-marvin-oceanides-images
description: Generate identity-consistent, realistic images of Marvin for Oceanides Malabanan personal-brand and service content using bundled current-body and face references. Use when asked to place Marvin in Oceanides septic or plumbing scenes, make Marvin UGC or field photos, create content-angle variants, preserve his current face/body/smile, or correct oversized heads, bodybuilder proportions, pasted-face looks, and other AI image artifacts.
---

# Generate Marvin Oceanides Images

Create believable phone-camera content photos of Marvin promoting Oceanides. Treat identity, current body proportions, and natural integration as harder requirements than cinematic polish.

## Use the original references

Use bundled originals only:

- `assets/marvin-body-master.jpg` — mandatory source of truth for Marvin's current body, head-to-body ratio, neck, shoulders, torso, arms, tattoo, watch, and overall appearance.
- `assets/marvin-smile.jpg` — use with the body master when a friendly teeth-visible smile is needed.
- `assets/marvin-face-front.jpg` — use with the body master for a front-facing neutral or mild expression.
- `assets/marvin-face-three-quarter.jpg` — use with the body master for a three-quarter facial angle.

Never use an AI-generated Marvin image as an identity or body reference unless the user explicitly requests it. Do not chain one generation into the next. If an output drifts, restart from the original assets.

Use no more than two identity references per generation by default:

1. Always attach `marvin-body-master.jpg`.
2. Add only the face reference that matches the requested angle or expression.

If the tool accepts only one reference, use the body master. Preserve its neutral expression or request only a subtle closed-mouth smile.

## Follow this workflow

1. Identify the requested scene, action, expression, camera angle, and output ratio. Use 4:5 vertical for feed content unless the user says otherwise.
2. Select the body master plus one matching face reference.
3. Read `references/prompt-template.md` and fill only the scene-specific placeholders.
4. Use the available image-generation or image-editing tool. Pass the original reference files directly when supported.
5. Inspect the result against `assets/marvin-body-master.jpg`, not against another generated image.
6. Apply every hard gate in `references/quality-control.md` before delivery.
7. If a hard gate fails, discard the output and regenerate from the originals with one targeted correction. Do not deliver an approximate likeness.

For multiple distinct scenes, issue one generation call per scene. Do not ask one call to create a collage or several unrelated assets.

## Lock Marvin's current body

Preserve the exact body visible in `marvin-body-master.jpg`:

- Normal, non-bodybuilder adult build.
- Natural torso width and length.
- Relaxed, slightly sloping shoulders.
- Average upper-arm and forearm thickness.
- Natural waist and midsection.
- Exact neck thickness and head-to-body ratio.
- Exact left-forearm tattoo placement and scale.
- Silver watch on the right wrist when visible.

Do not call Marvin broad, solid, athletic, heroic, powerful, muscular, or V-shaped in prompts. Those terms commonly inflate his body.

Do not widen or square his shoulders, enlarge his chest or arms, tighten his shirt, add muscle definition, slim his waist, change his height, or alter his weight.

Use a relaxed-fit navy crew-neck field shirt by default. Match the sleeve width, fabric drape, and silhouette of the black shirt in the body master. Add only a small Oceanides-blue `#38B6FF` accent. Do not invent a logo.

## Lock face and anatomy integration

Preserve Marvin's real head shape, hairline, short faded haircut, eyebrows, eyes, eyelids, nose, cheeks, ears, jaw, lips, light mustache, sparse chin stubble, skin tone, and natural pores.

Render Marvin as one continuous person:

- Keep the head size exactly proportional to the body master.
- Keep a natural jaw-to-neck, ear-to-neck, collar, shoulder, and shirt connection.
- Match light direction, skin tone, texture, softness, grain, focus, and white balance across face, neck, arms, and hands.
- Keep the face no sharper, brighter, smoother, or more detailed than the body.
- Avoid cutout hair, halos, floating heads, face swaps, pasted faces, or zoomed selfie faces.

Never beautify, age, de-age, slim, or reshape his face. Do not add a beard or change his haircut.

## Use natural camera defaults

Default to an ordinary recent phone's 2x rear camera at about 50mm equivalent, standard photo mode, from roughly 2.5–3 meters away. Use eye- or chest-height framing.

Avoid selfie cameras, wide-angle close-ups, portrait-mode blur, studio lighting, cinematic rim light, hyper-sharp detail, beauty retouching, and luxury-editorial posing.

Prefer natural overcast or open-shade daylight, slight phone HDR, mild JPEG softness, modest dynamic range, and only a mildly soft background. The result should look like a coworker took it during a real job.

## Keep Oceanides scenes credible

Use a clean blue septic vacuum truck, realistic heavy suction hoses, ordinary Philippine homes or commercial properties, and practical navy/blue field clothing. Keep equipment mechanically believable.

Do not show exposed sewage, dirty splashes, fake certifications, invented phone numbers, unreadable logos, garbled text, or unsafe work. Leave clean negative space for copy instead of rendering marketing text into the photo.

Read `references/content-angles.md` when the user wants ideas or a batch of scenes.

## Recover from common failures

- **Body too large or muscular:** restart from the body master; repeat exact current proportions and ban shoulder, chest, and arm enlargement. Never compensate by shrinking the head.
- **Head too large or zoomed:** restart from originals; use the body master's exact head-to-body ratio and a 50mm camera from 3 meters away. Never compensate by widening the body.
- **Pasted-face look:** restart from originals; require one continuous exposure and matched light, texture, focus, neck, and collar integration.
- **Face drift:** use the body master plus only one matching face reference. Remove beauty, celebrity, fashion, and cinematic language.
- **Artificial polish:** switch to ordinary phone-camera softness, open shade, standard mode, and candid posture.
- **Bad hands or equipment:** simplify the action and regenerate. Do not hide a failed hand with cropping unless the user specifically requests a crop.

## Resources

- `references/prompt-template.md` — master prompt and retry blocks.
- `references/content-angles.md` — useful Oceanides personal-brand scenes.
- `references/quality-control.md` — hard delivery gates.
- `assets/` — original Marvin reference photos. Do not modify them.
