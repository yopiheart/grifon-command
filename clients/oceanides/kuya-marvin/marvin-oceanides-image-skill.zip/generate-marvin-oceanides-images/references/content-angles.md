# Oceanides Content Angles for Marvin

Choose one clear story per image. Keep the action simple so identity and anatomy stay stable.

| Angle | Scene | Useful message |
| --- | --- | --- |
| Owner on site | Marvin stands beside the passenger side of a clean blue vacuum truck, phone at his side | The owner checks real jobs |
| Honest inspection | Marvin holds a blank clipboard beside a safely closed septic access cover | Explain first, recommend second |
| Customer trust | Marvin speaks with a homeowner after a completed job; avoid complex hand poses when possible | Real service, real accountability |
| Field walkthrough | Marvin walks slowly beside the truck while a distant technician packs hoses | Behind the service |
| Maintenance tip | Marvin points to a clean, closed access cover or an ordinary pipe connection | Teach one simple prevention tip |
| Property-manager report | Marvin reviews a blank tablet or clipboard in a clean commercial service area | Clear reports for properties |
| Team briefing | Marvin speaks with two distant technicians beside organized equipment | Trained people, clear process |
| Ready to respond | Marvin stands near the truck at the start of a workday | Prepared team and equipment |
| Completed-job check | Marvin checks that hoses are coiled and the work area is clean | We leave the site orderly |
| Plumbing diagnosis | Marvin studies a visible, clean pipe connection with a basic tool | Find the cause before repair |
| Myth-busting post | Marvin faces the camera beside a closed septic cover, one simple open-hand gesture | Correct a common septic myth |
| Founder story | Marvin stands in a quiet yard with the Oceanides truck softly behind him | Personal story and company values |

## Default composition

- Use 4:5 vertical for Facebook and Instagram feed.
- Place Marvin on one third of the frame.
- Keep clear wall, sky, or truck-side space for later copy.
- Show enough equipment to prove the setting without making the image busy.
- Keep background people distant and secondary.
- Avoid exposed waste, fake certificates, dramatic emergencies, or gross scenes.

## Content mix

For a batch, aim for:

- 50% education and inspection.
- 30% real field proof and behind-the-scenes work.
- 20% founder story, values, and customer trust.

Use cinematic hero imagery only for occasional covers. Default daily content to believable phone-camera documentation.
