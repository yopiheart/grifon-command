# Marvin Image Quality Control

Compare every output directly with `assets/marvin-body-master.jpg` and the selected original face reference.

## Hard gates

Reject and regenerate if any answer is no:

1. Is this unmistakably Marvin rather than a similar-looking man?
2. Does his body match the current body master without added muscle, width, height, or slimming?
3. Is the head-to-body ratio the same as the body master?
4. Do the jaw, neck, collar, shoulders, and shirt connect naturally?
5. Do face and body share the same lighting, softness, grain, color, and focus?
6. Are the left-forearm tattoo and right-wrist watch accurate when visible?
7. Are hands, fingers, phone, hoses, truck, and plumbing equipment believable?
8. Does the result look like an ordinary coworker phone photo rather than an AI composite or glossy ad?
9. Is there no unreadable text, invented logo, watermark, exposed waste, or unsafe scene?
10. Is there useful negative space for later content copy?

## Visual warning signs

- Face is larger or sharper than the body.
- Shoulders are squared, widened, or lifted.
- Chest or arms look trained or bodybuilder-like.
- Shirt stretches over the chest or arms instead of hanging loosely.
- Neck is too thin, too long, or disconnected from the jaw.
- Hair or ears have a light halo.
- Skin color changes at the jaw or collar.
- Background blur resembles portrait mode.
- Equipment looks decorative rather than functional.

## Retry policy

- Restart from the original body master and one original face reference.
- State one failure and one correction. Do not stack many new creative changes into a retry.
- Never fix a large head by enlarging the body.
- Never fix a small body by shrinking the head.
- Never fix identity drift by using the failed AI output as a new reference.
- Deliver only after all hard gates pass.
