# Marvin Oceanides Prompt Template

Use this template with `assets/marvin-body-master.jpg` plus one matching original face reference. Replace bracketed fields. Remove unused lines.

## Master template

```text
Use case: identity-preserve.

Generate one completely new, realistic [4:5 vertical] smartphone photograph for Oceanides Malabanan personal-brand content. Use only the supplied original Marvin photographs. Do not use or imitate any prior AI-generated image.

INPUT ROLES
- The body-master image is the source of truth for Marvin's exact current body, head-to-body ratio, neck, shoulders, torso, arms, tattoo, watch, and overall appearance.
- The second original image is used only for Marvin's [front / three-quarter] face and [neutral / mild / teeth-visible friendly] expression.

EXACT CURRENT BODY — HIGHEST PRIORITY
Preserve the body-master image exactly: normal non-bodybuilder build, natural torso width and length, relaxed slightly sloping shoulders, average arms, natural waist and midsection, exact neck thickness, and exact head-to-body scale. Keep the exact left-forearm tattoo placement and scale when visible.

Do not broaden or square his shoulders. Do not enlarge his chest, back, deltoids, biceps, forearms, thighs, or frame. Do not make him muscular, athletic, V-shaped, heroic, taller, thinner, heavier, or more defined. Do not tighten his shirt. Match the body master's relative widths of head, neck, shoulders, torso, hips, arms, and legs.

EXACT FACE AND INTEGRATION
Preserve Marvin's real head shape, hairline, short faded haircut, eyebrows, eyes, eyelids, nose, cheeks, ears, jaw, lips, light mustache, sparse chin stubble, skin tone, and natural pores. Use only the requested expression from the second original.

Render Marvin as one continuous naturally photographed person, never a face placed on another body. Keep natural jaw-to-neck, ear-to-neck, collar, shoulder, and shirt connections. Face, scalp, ears, neck, arms, and hands must share the same light, skin texture, softness, grain, color, and focus. The head must be neither enlarged nor reduced relative to the body master. No halo, cutout, floating head, pasted face, or face-swap look.

NEW SCENE
[Describe one real Oceanides scene.]

Marvin's action: [simple believable action].
Expression and eye line: [expression and where he looks].
Wardrobe: relaxed-fit navy crew-neck field shirt matching the body master's silhouette, with one small Oceanides-blue #38B6FF accent; dark straight work pants. Keep the right-wrist silver watch and left-forearm tattoo when visible.
Background: [clean blue vacuum truck / realistic hose / Filipino home or commercial property].
Copy space: [left / right / upper area].

CAMERA
Shot by a coworker from about 2.5–3 meters away using an ordinary phone's 2x rear camera, about 50mm equivalent, standard photo mode. [Eye / chest]-height camera. Frame Marvin from [waist / mid-thigh / knees] to above his head. No selfie perspective, close wide-angle distortion, or portrait-mode blur. Use natural [overcast / open-shade] daylight, slight phone HDR, mild JPEG softness, modest dynamic range, and a mildly soft background. Make it look like a real workday snapshot, not cinematic advertising.

No text, phone numbers, invented logos, watermarks, fake signage, exposed sewage, dirty splashes, duplicate Marvin, extra fingers, distorted hands, warped equipment, plastic skin, bodybuilder body, oversized face, or pasted head.
```

## Reference selection

| Requested result | Attach |
| --- | --- |
| Neutral or serious front view | `marvin-body-master.jpg` + `marvin-face-front.jpg` |
| Friendly teeth-visible smile | `marvin-body-master.jpg` + `marvin-smile.jpg` |
| Three-quarter face | `marvin-body-master.jpg` + `marvin-face-three-quarter.jpg` |
| Tool supports one reference only | `marvin-body-master.jpg` only |

## Targeted retry blocks

Add only the block that matches the failure, then regenerate from originals.

### Body inflated

```text
The rejected result enlarged Marvin's shoulders, chest, arms, or frame. Rebuild him using the exact current body in the body-master image. Keep relaxed sloping shoulders, average arms, natural midsection, loose shirt drape, and the original head-to-body ratio. Do not use athletic, broad, solid, heroic, or muscular anatomy.
```

### Head enlarged

```text
The rejected result enlarged or zoomed Marvin's head. Match the body master's exact head-to-body scale. Photograph from 3 meters away at 50mm equivalent. Keep the body unchanged; do not widen the shoulders to compensate.
```

### Face pasted on

```text
The rejected result looked like a face swap. Re-render Marvin as one continuous human in one exposure. Rebuild the hair edge, ears, jaw, neck, collar, shoulders, and shirt folds together. Match light, texture, softness, grain, white balance, and focus across face and body.
```

### Face drift

```text
The rejected result changed Marvin's identity. Preserve the exact original facial geometry and skin features. Remove beauty, celebrity, model, editorial, and cinematic styling. Use the body master plus only one original face reference.
```
